package santasWorkshop.models;

public abstract class BasicMethods {



    public static boolean checkEnergy(int energy) {
        return energy - 10 < 0;
    }

}
