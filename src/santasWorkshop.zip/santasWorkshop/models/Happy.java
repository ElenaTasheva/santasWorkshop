package santasWorkshop.models;

public class Happy extends BaseDwarf {

    private final static int INITIAL_ENERGY = 100;

    public Happy(String name) {
        super(name, INITIAL_ENERGY);
    }
}
